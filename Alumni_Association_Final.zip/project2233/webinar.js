// Handle "Register Now" Button Click
document.querySelector('.hero-content .btn').addEventListener('click', function (e) {
  e.preventDefault();
  alert('Redirecting to the registration page...');
  window.location.href = 'register.html'; // Redirect to the registration page
});

// Optional: Add animations or other interactivity
document.addEventListener('DOMContentLoaded', function () {
  // Add any additional JavaScript functionality here
});